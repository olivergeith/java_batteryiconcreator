#!/sbin/sh
# Universal Flasher tool by JRsoft & Intronauta
# More info http://www.htcmania.com/showthread.php?t=258333
# UFT is based in the "vrtheme system". More info about vrtheme: www.villainrom.co.uk
##
##
##
# This file is part of Universal Flasher Template.
#
# Universal Flasher tool is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or any later version.
#
# Universal Flasher tool is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
# See the GNU General Public License for more details: <http://www.gnu.org/licenses/>

# [ UFT v4.3 ]



#MOUNTING AS DEFINED IN UTF.config 
CHECK=0
i=1
until [ $CHECK = 1 ];do
	f=`cat /cache/tools/UFT.config | grep MOUNT$i | cut -d ":" -f 2`
        if [ `echo $f | wc -c` != 1 ];then
		$f
	else
		CHECK=1
	fi
       	i=$(( $i + 1 ))
done



#MOUNTING VIRTUAL FOLDER
`cat /cache/tools/UFT.config | grep VIRTUAL | cut -d ":" -f 2`

