[UTF v4.0]

##################################################################

    This file is part of the "Universal Flasher Tool" Template.

                 PLEASE, DON'T DELETE THIS FILE

##################################################################




#######################   L I C E N S E ###########################

Universal Flasher tool is free software: you can redistribute it 
and/or modify it under the terms of the GNU General Public License
as published by the Free Software Foundation, either version 3 of 
the License, or any later version.

Universal Flasher tool is distributed in the hope that it will be 
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details: 
<http://www.gnu.org/licenses/>


Do not modify the file header updater-script in order to maintain 
the original provisions of the Universal Flasher Tool:


	ui_print("       <<-----------------------------");
	ui_print("        UNIVERSAL FLASHER TOOL  v.X.X");
	ui_print("           by  JRsoft & Intronauta");
	ui_print("           - - - - - - - - - - - -    ");
	ui_print("       based in  <VillainTheme System>");
	ui_print("       ----------------------------->>");




#################### H O W T O      W O R K S #####################

Very simple:

>> Put in "/XTRAS" folder files that you want to add recreating 
their full paths. Note that /XTRAS is equivalent to root path in 
the internal memory:


  e.g: 

    /XTRAS/system/etc/gps.conf
    /XTRAS/sdcard/Wallpapers/MILF.jpeg
    /XTRAS/data/app/Youtube.apk
    /XTRAS/whateverfolder/whateverfile



>> Put in "/MORPH" folder your "morph themes". Note that /MORPH is
equivalent to root path in the internal memory and you must rename
folders like the apk but with extension instead the metamorph form
This process will only works in the following folders: /data/app, 
/system/app and /system/framework.


  [[[[[  CAUTION, ARMAGEDDON, KRAKEN IS COMMING, TEETS!!  ]]]]]

     [ DON'T APPLY MORPH TO MARKET APPS, IT'S INCOMPATIBLE ]
                      [ YOU ARE ADVICED ]


  e.g:
 
    /MORPH/system/app/Settings.apk/res/drawable-hdpi/***.png
    /MORPH/system/app/Settings.apk/classes.dex
    /MORPH/system/framework/framework-res.apk/resources.arsc
    /MORPH/data/app/****.apk/res/drawable-hdpi/**.png




>> It's very important that you take a look to MOD.config file to 
enable or disable features a/or set special commands if you need 
it, i.e for setup your sdcard layout used in your recovery if you 
get sdcard errors, set a mod name visible in Settings, etc..



>> Flash and enjoy!!


###################### KNOWN ERRORS ###############################


>>If you get (Status 0) error flashing, you need an update-binary 
specific for your terminal. You must look for and extract the
"/META-INF/com/google/android/update-binary" file inside a zip 
compatible with your terminal and replace it in the same path into 
the UFT. You also can consider to replace the whole META-INF folder
in the MOD with the other compatible, except the updater-script!!


>>Please, report us errors if you get!!



######################### A B O U T ###############################

>> Don't forget to check for more info, updates, requests or error 
reports related to "Universal Flasher tool" here:
http://www.htcmania.com/showthread.php?t=258333


>> And more info and updates about "VillainTheme System" here:
http://forum.xda-developers.com/showthread.php?t=1207017




###################### T H A N K S   T O ##########################

>> "Villain Team" for the concept
>> "Stericson" for "Metamorph" system
>> "Core Utilities" for the tar binary
>> "Blades" for the 7z binary and libs
>> Builders of "zip" and "zipalign" binaries.
>> Testers, especially to:
   "SuperCocoV6.5@htcmania", "lexullde@htcmania", "shayne77@xda",
   "vvaleta@htcmania" and "eladios@htcmania". 
>> "D.O.C@xda" for helping with the translations.
